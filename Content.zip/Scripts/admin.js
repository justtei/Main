﻿mslc.resolve(['admin/extends/ko'], function(ko) {
    ko.extend();
});