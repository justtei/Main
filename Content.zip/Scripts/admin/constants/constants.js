﻿mslc.define('admin/constants', [], function() {
    'use strict';
    
    return {
        MAX_INT: 2147483647,
        MAX_MONEY: 922337203685477.5807
    };
});