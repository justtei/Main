﻿mslc.define('admin/models/enums/seoPageType', [], function() {
    'use strict';

    return {
        INDEX: '1',
        SEARCH_RESULT: '2',
        SEARCH_DETAILS: '3'
    };
});