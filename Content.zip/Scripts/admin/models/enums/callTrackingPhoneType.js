﻿mslc.define('admin/models/enums/callTrackingPhoneType', [], function() {
    'use strict';

    return {
        PROVISION_ONLINE: '11',
        PROVISION_PRINT_AD: '12',
        PROVISION_CAMPAIGN: '13',
        PROVISION_ONLINE_AND_PRINT_AD: '16'
    };
});