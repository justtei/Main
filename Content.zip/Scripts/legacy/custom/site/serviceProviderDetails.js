﻿$(function ()
{
    $('#shortDescription a').on('click', showFullDescription);
    $('#fullDescription a').on('click', hideFullDescription);
    $('.lead-form').on('submit', submitLeadForm);
    $('#email-coupon').on('click', showCouponLeadForm);
    customDatePicker(document.body);
});